<?php
   $db=mysqli_connect("localhost", "root","","clothesecomm_db");
?>