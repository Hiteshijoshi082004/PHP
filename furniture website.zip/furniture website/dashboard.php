<?php
include("header.php")
?>

<?php
include("commoncode.php")
?>


<?php
include("footer.php")
?>